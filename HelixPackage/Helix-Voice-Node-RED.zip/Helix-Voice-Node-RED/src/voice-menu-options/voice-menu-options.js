
/** @param {import("node-red").NodeRedApp} RED */
module.exports = function (RED) {
    const AppManager = require("../app/app.manager")(RED);
    function VoiceMenuOptionsNode(config) {
        RED.nodes.createNode(this, config);
        
        var node = this;
        this.commandAliases = config.commandAliases;
        this.name = config.name;
        node.on("input", function (msg) {
            const sessionId = msg.sessionId;
            const menuOptions = AppManager.getMenuOptions(node, sessionId);
            msg.payload = menuOptions
                .map((node) => AppManager.getAliasList(node))
                .map((aliases) => aliases.length > 0 ? aliases[0] : null)
                .filter((alias) => alias);
            node.send(msg);
        });
    }

    RED.nodes.registerType("voice-menu-options", VoiceMenuOptionsNode);
}