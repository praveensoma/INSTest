const appManager = require("../app/app.manager");

/** @param {import("node-red").NodeRedApp} RED */
module.exports = function (RED) {
    const AppManager = require("../app/app.manager")(RED);
    const COMMAND_STRING_MATCH_CONFIDENCE_TARGET = 0.8;
    const COMMAND_STRING_PROPERTY_NAME = "payload";

    /**
     * A string matching algorithm which returns a string match confidence interval.
     * @param {string} commandAlias 
     * @param {string} commandString 
     * @returns {number}
     */
    function evaluateStringMatchConfidence(commandAlias, commandString) {
        // TODO: Add string matching algorithm here. An "indexOf" evaluation is likely not sufficient.
        const confidence = commandString.toLowerCase().indexOf(commandAlias.toLowerCase()) + 1;
        return confidence;
    };

    /**
     * Determines if a given `VoiceMenuItemNode` sufficiently matches the provided command.
     * @param {VoiceMenuItemNode} node 
     * @param {string} commandString 
     */
    function commandMatchesMenuItem(node, commandString) {
        const commandAliases = AppManager.getAliasList(node);
        const doesMatch = commandAliases.some((alias) => evaluateStringMatchConfidence(alias, commandString) > COMMAND_STRING_MATCH_CONFIDENCE_TARGET);
        return doesMatch;
    };

    async function makeApi(node){
        
        return new Promise((resolve, reject) => {
            const request = node.context().global.get('request');
            request(node.apiEndPoint, function (error, response, body) {
                if(body){
                    resolve(JSON.parse(body));
                }
            });
        })
        
    };

    /**
     * Creates an array of messages based on the connection points and the nodes they connect to.
     * The array will contain either the `outputMessage` or `null`.
     * @param {VoiceMenuItemNode} node
     * @param {string} commandString 
     * @param {any} outputMessage 
     * @returns {Array}
     */
    async function mapOutputMessagesByMenuCommands(node, sessionId, commandString, outputMessage) {
        /** This variable helps prevent messages from being sent to multiple VoiceMenuNodes
            that are connected via different connection points.
            
            In other words, we only want to send messages to a connection point if it fulfills the 
            following conditions:
            
            1. The connection point contains no `VoiceMenuItemNode`s 
            2. All the `VoiceMenuItemNode`s on a connection point matches with the `commandString`
            3. All previous connection points containing `VoiceMenuItemNode`s DID NOT match the `commandString`. */
        let commandAlreadyMatched = false;
        const connectedWires = [].concat.apply([], node.wires);
        const connectedNodes = connectedWires.map(wire => RED.nodes.getNode(wire));

        /** This will contain an array of message objects or `null` for each connection point in the node. */
        const output = [];
        // for (let i = 0; i < node.wires.length; i++) {
        //     /** @type {Array} */
        //     // const connectedWires = node.wires[i];

        //     /** Check every VoiceMenuItemNode within a connection point to see if the commands match.
        //         Every connected VoiceMenuItemNode on a single connection point MUST match the command. */
        //     const matchedMenuItems = AppManager.getMenuOptions(node, sessionId)
        //         .map((childNode) => commandMatchesMenuItem(childNode, commandString));

        //     const shouldSendMessage = matchedMenuItems.length === 0
        //         || (matchedMenuItems.every((match) => match === true) && commandAlreadyMatched === false);

        //     // We need to update this variable. We should set this to `true` when the array of
        //     // matched menu nodes has elements and that every element matches the commandString.
        //     commandAlreadyMatched = commandAlreadyMatched ||
        //         (matchedMenuItems.length > 0 && matchedMenuItems.every((match) => match === true));
        //     if (shouldSendMessage === true) {
        //         output[i] = outputMessage;
        //     } else {
        //         output[i] = null;
        //     }
        // }

        const commandMenuTypes = ["voice-menu-item", "voice-menu-options"];
        const session = AppManager.getSession(node, sessionId);
        console.log('node.apiEndPoint', node.apiEndPoint);
        if(node.apiEndPoint){
            let orders = await makeApi(node);
            session.menu = {};
            session.menu.orders = orders;
            session.menus = [];
            let newObj = {
                command : node.commandAliases,
                prompt : ""
            }
            session.menus.push(newObj);
        }

        let loopText = null;
        let loopTextIndext = null;
        if (node.enableMenuBuilder === true) {
            loopText = node.commandAliases;
            loopTextIndext = session.menu[loopText+'Index'] ? session.menu[loopText+'Index'] : 0;
            console.log('loopTextIndext', loopTextIndext);
            let loopTextArray = outputMessage['iterateObj'] ? outputMessage['iterateObj'][loopText] : session.menu[loopText];
            console.log('loopTextArray', loopTextArray);
            session.menu[loopText] = loopTextArray;
            let loopTextObj = loopTextArray[loopTextIndext] ? loopTextArray[loopTextIndext] : null;

            let isEndLoopNode = connectedNodes.filter(cNodes => cNodes.enableMenuBuilder == false);
            if(isEndLoopNode.length > 0 ){
                for (let j = 0; j < loopTextArray.length; j++) {
                    var promptText = node.prompt;
                    loopTextArray[j].rack ? promptText = promptText.replace(/{rack}/g, loopTextArray[j].rack) : "";
                    loopTextArray[j].shelf ? promptText = promptText.replace(/{shelf}/g, loopTextArray[j].shelf) : "";
                    loopTextArray[j].amount ? promptText = promptText.replace(/{amount}/g, loopTextArray[j].amount) : "";

                    let newObj = {
                        command: loopTextArray[j].checkDigit ? loopTextArray[j].checkDigit : "",
                        prompt: promptText
                    }
                    session.menus.push(newObj);
                }
                outputMessage['iterateObj'] = null;
            }
            
            if(isEndLoopNode.length == 0){
                var promptText = node.prompt;
                loopTextObj.order ? promptText = promptText.replace(/{order}/g, loopTextObj.order) : "";
                loopTextObj.positions ? promptText = promptText.replace(/{positions}/g, loopTextObj.positions) : "";
                loopTextObj.aisle ? promptText = promptText.replace(/{aisle}/g, loopTextObj.aisle) : "";
                let cmdText = loopTextObj.order ? loopTextObj.order : loopTextObj.aisle ? loopTextObj.aisle  : ""; 
                let newObj = {
                    command: loopTextObj.command ? loopTextObj.command + ' ' + cmdText : "",
                    prompt: promptText
                }
                session.menus.push(newObj);
                outputMessage['iterateObj'] = loopTextObj;
            }
            
            session.menu[loopText+'Index'] = loopTextIndext + 1;
        }

        for (let i = 0; i < connectedNodes.length; i++) {

            output[i] = null;

            const linkCommand = connectedNodes.filter(cNodes => cNodes.type === 'link call').map(mNode => mNode.name);
            const command = connectedNodes.filter(cNodes => commandMenuTypes.includes(cNodes.type)).map(mNode => mNode.commandAliases);
            let commands = [...linkCommand, ...command]
            commands.length > 0 ? outputMessage.command = commands : "";

            let cmdIndex = null;
            session.menus && session.menus.length > 0 ? cmdIndex = session.menus.findIndex(element => element.command == commandString) : "";

            if (commandMenuTypes.includes(connectedNodes[i].type) && connectedNodes[i].commandAliases.includes(commandString)) {
                console.log('1');
                output[i] = outputMessage;
            } else if ((connectedNodes[i].type === 'link call' && connectedNodes[i].name === commandString) || (connectedNodes[i].enableMenuBuilder && node.apiEndPoint)) {
                console.log('2');
                output[i] = outputMessage;
                AppManager.pushCommand(connectedNodes[i], sessionId);
            } else if (node.enableLoop === true && session.menus && session.menus.length > 0) {
                console.log('4');
                // outputMessage.command = null;

                if(cmdIndex == session.menus.length-1){
                    outputMessage.prompt = 'Order Completed!'
                }else{
                    if(cmdIndex >=0 ){
                        outputMessage.command = session.menus[cmdIndex + 1].command;
                        outputMessage.prompt = session.menus[cmdIndex + 1].prompt;
                    } 
                    // else {
                    //     outputMessage.command = "";
                    //     outputMessage.prompt = "";
                    // }
                    
                }
                output[i] = outputMessage;
            } else if (node.enableMenuBuilder === true) {
                console.log('5');
               
                // let loopText = node.commandAliases;
                // let loopTextIndext = session.menu[loopText+'Index'] ? session.menu[loopText+'Index'] : 0;
                // console.log('loopTextIndext', loopTextIndext);
                // let loopTextArray = outputMessage['iterateObj'] ? outputMessage['iterateObj'][loopText] : session.menu[loopText];
                // console.log('loopTextArray', loopTextArray);
                // session.menu[loopText] = loopTextArray;
                // let loopTextObj = loopTextArray[loopTextIndext] ? loopTextArray[loopTextIndext] : null;

                // let isEndLoopNode = connectedNodes.filter(cNodes => cNodes.enableMenuBuilder == false);
                // if(isEndLoopNode.length > 0 && connectedNodes[i].enableMenuBuilder == true){
                //     for (let j = 0; j < loopTextArray.length; j++) {
                //         var promptText = node.prompt;
                //         loopTextArray[j].rack ? promptText = promptText.replace(/{rack}/g, loopTextArray[j].rack) : "";
                //         loopTextArray[j].shelf ? promptText = promptText.replace(/{shelf}/g, loopTextArray[j].shelf) : "";
                //         loopTextArray[j].amount ? promptText = promptText.replace(/{amount}/g, loopTextArray[j].amount) : "";

                //         let newObj = {
                //             command: loopTextArray[j].checkDigit ? loopTextArray[j].checkDigit : "",
                //             prompt: promptText
                //         }
                //         session.menus.push(newObj);
                //     }
                //     outputMessage['iterateObj'] = null;
                // }
                
                // if(isEndLoopNode.length == 0){
                //     var promptText = node.prompt;
                //     loopTextObj.order ? promptText = promptText.replace(/{order}/g, loopTextObj.order) : "";
                //     loopTextObj.positions ? promptText = promptText.replace(/{positions}/g, loopTextObj.positions) : "";
                //     loopTextObj.aisle ? promptText = promptText.replace(/{aisle}/g, loopTextObj.aisle) : "";
                //     let cmdText = loopTextObj.order ? loopTextObj.order : loopTextObj.aisle ? loopTextObj.aisle  : ""; 
                //     let newObj = {
                //         command: loopTextObj.command ? loopTextObj.command + ' ' + cmdText : "",
                //         prompt: promptText
                //     }
                //     session.menus.push(newObj);
                //     outputMessage['iterateObj'] = loopTextObj;
                // }
                
                // session.menu[loopText+'Index'] = loopTextIndext + 1;

                let isPreviousNodeTrue = connectedNodes.filter(cNodes => session.menu[cNodes.commandAliases+'State'] == true);
                if (commandMenuTypes.includes(connectedNodes[i].type) && connectedNodes[i].enableMenuBuilder == true && session.menu[connectedNodes[i].commandAliases+'State'] == false) {
                    output[i] = null;
                    session.menu[loopText+'Index'] = 0;
                    // session.menu[loopText+'State'] = false;
                    console.log('1.1');
                    // delete session.menu;
                } else if(isPreviousNodeTrue.length > 1 && connectedNodes[i].enableMenuBuilder == false) {
                    output[i] = null;
                    session.menu[loopText+'Index'] = 0;
                    console.log('1.2');
                } else if(isPreviousNodeTrue.length == 1 && connectedNodes[i].enableMenuBuilder == false){
                    output[i] = outputMessage;
                    console.log('1.3');
                } else {
                    if (loopTextIndext == session.menu[loopText].length - 1) {
                        session.menu[loopText+'State'] = false;
                        session.menu[loopText+'Index'] = 0;
                        console.log('1.4');
                        output[i] = outputMessage;
                    } else {
                        if((connectedNodes[i-1] && connectedNodes[i-1].commandAliases && session.menu[connectedNodes[i-1].commandAliases+'State'] == true) && (commandMenuTypes.includes(connectedNodes[i].type) && connectedNodes[i].enableMenuBuilder == true)){
                            output[i] = null;
                            console.log('1.6');
                        }else{
                            session.menu[loopText+'State'] = true;
                            console.log('1.5');
                            output[i] = outputMessage;
                            // connectedNodes.map(cNode => cNode.commandAliases ? session.menu[cNode.commandAliases+'State'] = true : '');
                            connectedNodes[i-1] ? session.menu[connectedNodes[i-1].commandAliases+'State'] = true : '';
                        }
                    }
                }
            } else if (session.menuTraversalState && session.menuTraversalState.includes(connectedNodes[i].id)) {
                console.log('3');
                if(connectedNodes[i].enableMenuBuilder == true){
                    output[i] = null;
                }else{
                    output[i] = outputMessage;
                }
            } else if (connectedNodes[i].type === 'voice-menu-end') {
                console.log('6');
                output[i] = outputMessage;
            } else if (!commandMenuTypes.includes(connectedNodes[i].type) && connectedNodes[i].type != 'link call') {
                console.log('7');
                output[i] = outputMessage;
            } 
        }
        console.log('output ' + node.name + ' | ', output);
        return output;
    };

    function VoiceMenuItemNode(config) {
        RED.nodes.createNode(this, config);
        var node = this;

        this.enabled = config.enabled;
        this.name = config.name;
        this.commandAliases = config.commandAliases;
        this.prompt = config.prompt;
        this.outputs = config.outputs;
        this.enableOptions = config.enableOptions;
        this.enableGlobalMenu = config.enableGlobalMenu;
        this.enableLoop = config.enableLoop;
        this.enableMenuBuilder = config.enableMenuBuilder;
        this.apiEndPoint = config.apiEndPoint;
        this.iterations = new Map();

        node.on("input", async function (msg) {

            if (node.enabled === true) {
                const sessionId = msg.sessionId;
                const commandString = msg[COMMAND_STRING_PROPERTY_NAME];
                // if (AppManager.shouldBypass(node, sessionId, commandString) === true) {
                //     AppManager.traverse(node, sessionId);
                //     const bypassOut = AppManager.createBypassOutput(node, sessionId, commandString, msg);
                //     console.log('bypassOut', bypassOut);
                //     node.send(bypassOut);
                //     return;
                // }
                // const outputMessage = { ...msg, command: node.name };
                // const outputs = mapOutputMessagesByMenuCommands(node, sessionId, commandString, outputMessage);
                // AppManager.pushCommand(node, sessionId);
                // node.send(outputs);
                AppManager.traverseNew(node, sessionId, commandString, msg);
                // const outputMessage = { ...msg, command: node.name };
                const outputs = await mapOutputMessagesByMenuCommands(node, sessionId, commandString, msg);
                AppManager.pushCommand(node, sessionId);
                node.send(outputs);
            }
        });
    }

    RED.nodes.registerType("voice-menu-item", VoiceMenuItemNode);
}