
/** @param {import("node-red").NodeRedApp} RED */
module.exports = function (RED) {
    const AppManager = require("../app/app.manager")(RED);
    function VoiceMenuEndNode(config) {
        RED.nodes.createNode(this, config);
        
        var node = this;
        
        this.name = "App End";
        node.on("input", function (msg) {
            const sessionId = msg.sessionId;
            
            AppManager.endApp(node, sessionId);
            AppManager.resetMenuTraversalState(node, sessionId);
            
            // TODO: rollback to the previous app.
        });
    }

    RED.nodes.registerType("voice-menu-end", VoiceMenuEndNode);
}