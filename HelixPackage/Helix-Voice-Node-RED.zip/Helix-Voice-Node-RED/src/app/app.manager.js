const APP_DEFAULTS = {
    commandCount: 0,
    commandHistory: [],
    sessionId: null,
    menuState: [],
    menuTraversalState: []
};

const commandMenuTypes = ["voice-menu-item", "voice-menu-options"];

module.exports = (RED) => ({
    getSessions: function (node) {
        /** @type {Map<string, any>} */
        let sessions = node.context().global.get("sessions");
        if (!sessions) {
            sessions = new Map();
            node.context().global.set("sessions", sessions);
        }

        return sessions;
    },
    getSession: function (node, sessionId) {
        const sessions = this.getSessions(node);
        const session = sessions.get(sessionId);
        return session;
    },
    createSession: function (node, sessionId) {
        const session = {
            ...APP_DEFAULTS,
            sessionId
        };
        const sessions = this.getSessions(node);
        sessions.set(sessionId, session);
        return session;
    },
    getApps: function (node) {
        /** @type {Map<string, any>} */
        let apps = node.context().flow.get("apps");
        if (!apps) {
            apps = new Map();
            node.context().flow.set("apps", apps);
        }
        return apps;
    },
    getApp: function (node, sessionId) {
        const apps = this.getApps(node);
        const app = apps.get(sessionId);
        return app;
    },
    startApp: function (node, sessionId, appName) {
        const session = this.getSession(node, sessionId);
        session.currentApp = appName;

        const app = {
            ...APP_DEFAULTS,
            sessionId
        };

        const apps = this.getApps(node);
        apps.set(sessionId, app);
        return app;
    },
    endApp: function (node, sessionId) {
        const apps = this.getApps(node);
        apps.delete(sessionId);
    },
    endSession: function (node, sessionId) {
        const sessions = this.getSessions(node);
        sessions.delete(sessionId);
    },
    resetMenuTraversalState: function (node, sessionId) {
        const session = this.getSession(node, sessionId);
        const app = this.getApp(node, sessionId);
        session.menuTraversalState = new Map();
        app.menuTraversalState = new Map();
    },
    pushCommand: function (node, sessionId) {
        const session = this.getSession(node, sessionId);
        const app = this.getApp(node, sessionId);

        // session.commandHistory.push(node.id);
        // session.menuState.push(node.id);
        // app.commandHistory.push(node.id);
        // app.menuState.push(node.id);
        if(session){
            session.commandHistory.includes(node.id) ?  "" : session.commandHistory.push(node.id);
            session.menuState.includes(node.id) ? "" : session.menuState.push(node.id);
            session.menuTraversalState.includes(node.id) ? "" : session.menuTraversalState.push(node.id);
        }
        
        if(app){
            app.commandHistory.includes(node.id) ? "" : app.commandHistory.push(node.id);
            app.menuState.includes(node.id) ? "" : app.menuState.push(node.id);
            app.menuTraversalState.includes(node.id) ? "" : app.menuTraversalState.push(node.id);
        }
    },
    traverse: function (node, sessionId) {
        const session = this.getSession(node, sessionId);
        const app = this.getApp(node, sessionId);
        // session.menuTraversalState.splice(0, 1);
        // app.menuTraversalState.splice(0, 1);
    },
    traverseNew: function (node, sessionId, commandString, msg) {
        const session = this.getSession(node, sessionId);
        const app = this.getApp(node, sessionId);
        
        let connectedWires = [].concat.apply([], node.wires);
        let connectedNodes = connectedWires.map(wire => RED.nodes.getNode(wire));

        let travelledNodes = app.menuTraversalState;
        // let menuNodes = connectedNodes.filter(cNodes => commandMenuTypes.includes(cNodes.type));
        // menuNodes.length === 0 ? this.isEndNode = true : this.isEndNode = false;

        let cmdPresentNodes = connectedNodes.filter(cNodes => ((cNodes.type === "voice-menu-item") && cNodes.commandAliases.includes(commandString) === true) || ((cNodes.type === "link call") && cNodes.name === commandString));
        if (cmdPresentNodes.length > 0) {
            let removableNodes = connectedNodes.filter(cNodes => ((cNodes.type === "voice-menu-item") && cNodes.commandAliases.includes(commandString) != true) || ((cNodes.type === "link call") && cNodes.name != commandString));
            if (travelledNodes && removableNodes.length > 0) {
                removableNodes.map((rNodes) => {
                    let rIndex = travelledNodes.findIndex(tNode => tNode === rNodes.id);
                    rIndex >= 0 ? travelledNodes.splice(rIndex) : '';
                });
                session ? session.menuTraversalState = travelledNodes : "";
                app ? app.menuTraversalState = travelledNodes : "";
            }
        }
    },
    createBypassOutput: function (node, sessionId, commandString, msg) {
        // const app = this.getApp(node, sessionId);
        const session = this.getSession(node, sessionId);
        const bypassOut = [];
        for (let i = 0; i < node.wires.length; i++) {
            bypassOut[i] = null;
            for (let j = 0; j < node.wires[i].length; j++) {
                const childNode = RED.nodes.getNode(node.wires[i][j]);
                if (commandString === "options" && childNode.type === "voice-menu-options") {
                    bypassOut[i] = msg;
                    break;
                } else {
                    // if (childNode.id === app.menuTraversalState[0]) {
                    //     bypassOut[i] = msg;
                    //     break;
                    // }
                    if (session.menuTraversalState.includes(childNode.id)) {
                        bypassOut[i] = msg;
                        break;
                    }
                }
            }
        }
        return bypassOut;
    },
    shouldBypass: function (node, sessionId, commandString) {
        const app = this.getApp(node, sessionId);
        const menuTraversalState = app.menuTraversalState;

        // return menuTraversalState[0] === node.id || commandString === "options";
        return menuTraversalState.includes(node.id) || commandString === "options";
    },
    getMenuOptions: function (node, sessionId) {
        // const commandMenuTypes = ["voice-menu-item", "voice-menu-options"];
        /** Check every VoiceMenuItemNode within a connection point to see if the commands match.
        Every connected VoiceMenuItemNode on a single connection point MUST match the command. */
        const options = node.wires
            .reduce((prev, curr) => [...prev, ...curr])
            .map((nodeId) => RED.nodes.getNode(nodeId))
            .filter((childNode) => commandMenuTypes.some((type) => childNode.type === type));
        return options;
    },
    getAliasList: function (node) {
        if (node.commandAliases) {
            const commandAliases = Array.isArray(node.commandAliases)
                ? [...node.commandAliases]
                : node.commandAliases.split(',').map((s) => s.trim());
            return commandAliases;
        }
        return null;
    }
});