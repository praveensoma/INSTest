/** @param {import("node-red").NodeRedApp} RED */
module.exports = function (RED) {
    const AppManager = require("../app/app.manager")(RED);
    function VoiceMenuStartNode(config) {
        RED.nodes.createNode(this, config);
        
        var node = this;
        
        this.name = config.name;
        node.on("input", function (msg) {
            const sessionId = msg.sessionId;
            let session = AppManager.getSession(node, sessionId);

            if (!session) {
                session = AppManager.createSession(node, sessionId);
                msg.sessionId = session.sessionId;
            }
            session.commandCount++;
            // session.menuTraversalState = session.menuState.reverse();

            let app = AppManager.getApp(node, sessionId);
            if (!app) {
                app = AppManager.startApp(node, sessionId, node.name);
            }
            // app.menuTraversalState = app.menuState.reverse();
            node.send(msg);
        });
    }

    RED.nodes.registerType("voice-menu-start", VoiceMenuStartNode);
}